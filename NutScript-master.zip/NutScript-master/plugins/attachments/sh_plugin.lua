local PLUGIN = PLUGIN;

PLUGIN.name = "Attachments"
PLUGIN.author = "LauScript"
PLUGIN.desc = "Adds weapon attachments to the player's appearance."

nut.util.Include("sv_hooks.lua");
nut.util.Include("sv_lib.lua");
nut.util.Include("sv_configuration.lua");
