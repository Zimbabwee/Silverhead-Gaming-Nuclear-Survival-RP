ITEM.name = "Wood Crate"
ITEM.model = Model("models/props_junk/wood_crate001a.mdl")
ITEM.uniqueID = "stor_crate"
ITEM.maxWeight = 8
ITEM.desc = "An old box made of wood."