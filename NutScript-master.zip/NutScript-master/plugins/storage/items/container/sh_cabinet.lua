ITEM.name = "Cabinet"
ITEM.model = Model("models/props_wasteland/controlroom_filecabinet001a.mdl")
ITEM.uniqueID = "stor_cab"
ITEM.maxWeight = 5
ITEM.desc = "A small, green filing cabinet."