ITEM.name = "Big Crate"
ITEM.model = Model("models/props_junk/wood_crate002a.mdl")
ITEM.uniqueID = "stor_bcrate"
ITEM.maxWeight = 16
ITEM.desc = "An large, old box made of wood."