ITEM.name = "Box"
ITEM.model = Model("models/props_junk/cardboard_box001a.mdl")
ITEM.uniqueID = "stor_box"
ITEM.maxWeight = 5
ITEM.desc = "A cardboard box sealed with packaging tape."