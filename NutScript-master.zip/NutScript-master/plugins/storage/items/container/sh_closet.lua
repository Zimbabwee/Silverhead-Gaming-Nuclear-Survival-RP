ITEM.name = "Storage Closet"
ITEM.model = Model("models/props_wasteland/controlroom_storagecloset001a.mdl")
ITEM.uniqueID = "stor_closet"
ITEM.maxWeight = 30
ITEM.desc = "A big, green storage closet."