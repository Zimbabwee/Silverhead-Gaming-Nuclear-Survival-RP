ITEM.name = "Small Drawer"
ITEM.model = Model("models/props_c17/FurnitureDrawer002a.mdl")
ITEM.uniqueID = "stor_sdrawer"
ITEM.maxWeight = 4
ITEM.desc = "A small piece of furniture."