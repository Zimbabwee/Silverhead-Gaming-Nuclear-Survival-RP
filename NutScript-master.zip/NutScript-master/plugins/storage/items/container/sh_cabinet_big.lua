ITEM.name = "Big Cabinet"
ITEM.model = Model("models/props_wasteland/controlroom_filecabinet002a.mdl")
ITEM.uniqueID = "stor_bcab"
ITEM.maxWeight = 20
ITEM.desc = "A tall, green filing cabinet."