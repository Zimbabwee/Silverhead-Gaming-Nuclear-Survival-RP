ITEM.name = "Locker"
ITEM.model = Model("models/props_c17/Lockers001a.mdl")
ITEM.uniqueID = "stor_locker"
ITEM.maxWeight = 25
ITEM.desc = "A set of lockers for placing stuff inside."