ITEM.name = "Drawer"
ITEM.model = Model("models/props_c17/FurnitureDrawer001a.mdl")
ITEM.uniqueID = "stor_drawer"
ITEM.maxWeight = 10
ITEM.desc = "A piece of furniture."