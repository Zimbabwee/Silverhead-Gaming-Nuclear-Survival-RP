ITEM.name = "Fridge"
ITEM.model = Model("models/props_c17/FurnitureFridge001a.mdl")
ITEM.uniqueID = "stor_fridge"
ITEM.maxWeight = 12
ITEM.desc = "An old fridge that has a slight yellow color."