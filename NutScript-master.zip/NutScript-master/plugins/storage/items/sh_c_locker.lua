ITEM.name = "Lock Pad"
ITEM.uniqueID = "classic_locker_1"
ITEM.category = "Storage Options"
ITEM.model = Model( "models/props_wasteland/prison_padlock001a.mdl" )
ITEM.desc = "Lock Pad. Can be lock-picked Easily."