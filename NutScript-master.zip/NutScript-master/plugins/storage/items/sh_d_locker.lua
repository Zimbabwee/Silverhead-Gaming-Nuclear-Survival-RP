ITEM.name = "Civil Purpose Digital Locker"
ITEM.uniqueID = "digital_locker_1"
ITEM.category = "Storage Options"
ITEM.model = Model( "models/props_lab/keypad.mdl" )
ITEM.desc = "A Digital lock that partially limited. Can lock a storage with 4 digits."