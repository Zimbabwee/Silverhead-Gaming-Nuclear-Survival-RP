ITEM.name = "Key"
ITEM.uniqueID = "key_generic"
ITEM.category = "Storage Options"
ITEM.weight = 0
ITEM.model = Model( "models/gibs/metal_gib1.mdl" )
ITEM.desc = "A Generic Key for specific storage"