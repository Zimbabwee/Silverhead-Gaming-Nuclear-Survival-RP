PLUGIN.name = "Chatbox"
PLUGIN.author = "Chessnut"
PLUGIN.desc = "Adds a chatbox to the schema and chat classes."
PLUGIN.disabled = true

nut.util.Include("sh_chatbox.lua")