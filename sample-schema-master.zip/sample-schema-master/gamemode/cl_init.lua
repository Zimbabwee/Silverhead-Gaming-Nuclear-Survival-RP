DeriveGamemode("nutscript");

nut.schema.Init();