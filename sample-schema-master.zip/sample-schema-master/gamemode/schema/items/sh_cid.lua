ITEM.name = "Citizen ID"
ITEM.model = Model("models/gibs/metal_gib4.mdl")
ITEM.desc = "An ID cards with the digits %Digits|00000% assigned to %Owner|no one%."
