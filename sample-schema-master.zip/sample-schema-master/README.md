Example Schema
=============

This is an example schema that should show the basics of how schemas are made with NutScript. Simply make a folder called 'sample' in the gamemodes/ folder with 'nutscript' and add this to your server's startup line: +gamemode sample
